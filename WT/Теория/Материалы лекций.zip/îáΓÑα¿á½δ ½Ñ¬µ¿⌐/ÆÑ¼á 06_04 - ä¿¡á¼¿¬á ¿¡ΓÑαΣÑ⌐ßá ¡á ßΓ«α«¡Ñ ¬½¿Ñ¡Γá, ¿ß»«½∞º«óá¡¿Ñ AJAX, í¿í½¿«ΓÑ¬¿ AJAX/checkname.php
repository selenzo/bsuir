<?

echo time();

?>