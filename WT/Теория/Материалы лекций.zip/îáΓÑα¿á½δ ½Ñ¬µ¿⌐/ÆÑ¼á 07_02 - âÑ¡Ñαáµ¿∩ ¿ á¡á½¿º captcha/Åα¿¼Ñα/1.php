<?

$image_x=200;
$image_y=50;
$symbol_min_angle=-45;
$symbol_max_angle=45;
$symbol_min_size=18;
$symbol_max_size=20;
$symbol_fonts = array("captcha1.ttf","captcha2.ttf","captcha3.ttf","captcha4.ttf","captcha5.ttf");
$lines_count=5;
$circles_count=5;

session_start();
$text=(string)rand(100000,999999);
$_SESSION["captcha"]=$text;

header("Content-type: image/png");
$im = imagecreatetruecolor($image_x, $image_y);

$background_color=imagecolorallocate($im, 200+rand(-50,50), 200+rand(-50,50), 200+rand(-50,50));

imagefill($im, 0, 0, $background_color);

// circles +++
for ($i=0;$i<$circles_count;$i++)
 {
  $cx=rand(0,$image_x);
  $cy=rand(0,$image_y);
  $ch=rand(0,round($image_x/10));
  $cw=rand(0,round($image_y/10));
  $cc=imagecolorallocate($im, 100+rand(-100,100), 100+rand(-100,100), 100+rand(-100,100)); //  color
  imageellipse($im, $cx, $cy, $cw, $ch, $cc);
  imagefill($im, $cx, $cy, $cc);   
 }
// circles ---

$step=round($image_x/(strlen($text)+2));
$sx=0;
for($i=0;$i<strlen($text);$i++)
 {
  $symb=$text[$i];
  $sx+=$step+(rand(-round($step/5),round($step/5))); // symbol x
  $sy=$image_y-round($image_y/3)+rand(-round($image_y/5),round($image_y/5)); // symbol y
  $sa=rand($symbol_min_angle,$symbol_max_angle); // symbol angle
  $ss=rand($symbol_min_size,$symbol_max_size); // symbol size
  $sf=$symbol_fonts[rand(0,count($symbol_fonts)-1)]; // symbol font
  $sc=imagecolorallocate($im, 50+rand(-50,50), 50+rand(-50,50), 50+rand(-50,50)); // symbol color
  imagettftext($im, $ss, $sa, $sx, $sy, $sc, $sf, $symb);
 }

// lines +++
for ($i=0;$i<$lines_count;$i++)
 {
  $st_x=rand(0,$image_x);
  $st_y=rand(0,$image_y);
  $en_x=rand(0,$image_x);
  $en_y=rand(0,$image_y);
  $lc=imagecolorallocate($im, 100+rand(-100,100), 100+rand(-100,100), 100+rand(-100,100)); //  color
  imageline($im, $st_x, $st_y, $en_x, $en_y, $lc);
 }
// lines ---


imagepng($im);
imagedestroy($im);




?>