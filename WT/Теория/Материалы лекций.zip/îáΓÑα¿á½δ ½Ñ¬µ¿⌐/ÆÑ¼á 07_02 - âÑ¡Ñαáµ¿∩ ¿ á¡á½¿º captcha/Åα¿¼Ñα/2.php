<? session_start(); ?>

<form action="2.php" method="post">
 <input type="text" name="captcha" />
 <input type="submit" value="Go!" />
</form>

<?

if (isset($_POST["captcha"]))
 {
//  print_r($_POST);
//  print_r($_SESSION);
  if ($_POST["captcha"]==$_SESSION["captcha"]) echo "Molodec!"; else echo "Durak!";
 }

?>


<img src="1.php" />