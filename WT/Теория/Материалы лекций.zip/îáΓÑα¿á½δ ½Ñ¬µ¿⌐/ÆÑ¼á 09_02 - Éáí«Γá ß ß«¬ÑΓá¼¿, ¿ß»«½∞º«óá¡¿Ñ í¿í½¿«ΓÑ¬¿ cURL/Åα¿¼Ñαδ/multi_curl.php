<?php

    $urls = file("urls.txt"); //�������� ������ �����
    
    $mh = curl_multi_init();

    foreach ($urls as $i => $url) {
      $conn[$i] = curl_init(trim($url));
      curl_setopt($conn[$i], CURLOPT_RETURNTRANSFER, 1);
      curl_multi_add_handle ($mh,$conn[$i]);
    }

    // start performing the request
    do {
      $mrc = curl_multi_exec($mh, $active);
    } while ($mrc == CURLM_CALL_MULTI_PERFORM);

    while ($active and $mrc == CURLM_OK) {
      // wait for network
      if (curl_multi_select($mh) != -1) {
                // pull in any new data, or at least handle timeouts
                do {
              $mrc = curl_multi_exec($mh, $active);
                } while ($mrc == CURLM_CALL_MULTI_PERFORM);
      }
    }

    if ($mrc != CURLM_OK) {
      print "Curl multi read error $mrc\n";
    }

    // retrieve data
    foreach ($urls as $i => $url) {
      if (($err = curl_error($conn[$i])) == '') {
                $res[$i]=curl_multi_getcontent($conn[$i]);
      } else {
                print "Curl error on handle $i: $err\n";
      }
      curl_multi_remove_handle($mh,$conn[$i]);
      curl_close($conn[$i]);
    }
    
    curl_multi_close($mh);

    print_r($res);

?>